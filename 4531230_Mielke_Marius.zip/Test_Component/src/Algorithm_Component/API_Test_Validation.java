package Algorithm_Component;

import fernuni.propra.algorithm.*;
import org.junit.Test;
import static org.junit.Assert.*;

/*
 * Informationen über das Unit-Testen mit Hilfe von JUnit finden Sie unter http://www.vogella.com/tutorials/JUnit/article.html.
 * In dem dort hinterlegten Dokument sind alle notwendigen Hilfsmittel erläutert.
 * 
 * Designen Sie Ihre Unit-Tests nach dem Arrange-Act-Assert-Prinzip
 */

public class API_Test_Validation {
	
	@Test
	public void validateFileHasToBeValid() {
		// Arrange
		IAusleuchtung api = new Ausleuchtung();
		// Act
		boolean solutionValid = api.validateSolution("");
		// Assert
		assertTrue("Ohne Angabe einer Datei wurde eine zulässige Lösung gefunden.", !solutionValid);
	}
	
	@Test
	public void validateTruePositive() {
		// Arrange
		IAusleuchtung api = new Ausleuchtung();
		// Act
		boolean solutionValid = api.validateSolution("instances/validationInstances/Selbsttest_20a_solved.xml");
		// Assert
		assertTrue("Eine zulässige Lösung wurde als nicht zulässig gewertet.", solutionValid);
	}
	
	@Test
	public void validateTrueNegative() {
		// Arrange
		IAusleuchtung api = new Ausleuchtung();
		// Act
		boolean solutionValid = api.validateSolution("instances/validationInstances/Selbsttest_20a_incomplete.xml");
		// Assert
		assertTrue("Eine unzulässige Lösung wurde als zulässig gewertet.", !solutionValid);
	}
}
